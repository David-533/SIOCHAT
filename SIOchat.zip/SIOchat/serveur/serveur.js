import { createServer } from "http";
import { Server } from "socket.io";

const httpServer = createServer();
const io = new Server(httpServer, {
    cors: {
        origin: "*"
    }
});

io.on('connection', (socket) => {
    console.log('Un utilisateur vient de se connecter');

    // Écoute de l'événement 'chat message'
    socket.on('chat message', (data) => {
        if (data.pseudo && data.message) {
            console.log(data);
            io.emit('chat message', data); // Envoi de l'objet complet au client
        }
    });

    socket.on('disconnect', () => {
        console.log('Un utilisateur s\'est déconnecté');
    });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
