import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';

const socket = io('http://172.16.7.197:3000');

function App() {
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);
    const [isPopupOpen, setIsPopupOpen] = useState(true);
    const [pseudo, setPseudo] = useState('');
    const pseudoInputRef = useRef(null);

    // Fonction pour envoyer un message
    function sendMessage(e) {
        e.preventDefault();
        if (message.trim() !== "") {
            socket.emit('chat message', { pseudo, message }); // Envoi du pseudo avec le message
            setMessage('');
        }
    }

    // Écoute des messages reçus du serveur
    useEffect(() => {
        socket.on('chat message', (data) => {
            setMessages((prevMessages) => [...prevMessages, `${data.pseudo}: ${data.message}`]); // Affichage correct du pseudo
        });

        return () => {
            socket.off('chat message');
        };
    }, []);

    // Fonction pour fermer le popup et enregistrer le pseudo
    const closePopup = () => {
        const pseudoValue = pseudoInputRef.current.value.trim();
        if (pseudoValue) {
            setPseudo(pseudoValue);
            setIsPopupOpen(false);
        } else { 
            alert("Veuillez entrer un pseudo valide.");
        }
    };

    // Composant Popup
    const Popup = ({ onClose }) => (
        <div style={popupOverlayStyles}>
            <div style={popupContentStyles}>
                <h2>Entrez votre pseudo</h2>
                <input
                    type="text"
                    ref={pseudoInputRef}
                    placeholder="Votre pseudo"
                    style={inputStyles}
                />
                <div style={buttonContainerStyles}>
                    <button onClick={onClose} style={buttonStyles}>Confirmer</button>
                </div>
            </div>
        </div>
    );

    return (
        <div>
            {isPopupOpen && <Popup onClose={closePopup} />}
            {pseudo && <div style={pseudoStyles}>Pseudo: {pseudo}</div>}

            <ul>
                {messages.map((msg, index) => (
                    <li key={index}>{msg}</li>
                ))}
            </ul>

            <form onSubmit={sendMessage}>
                <input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    autoComplete="off"
                    style={inputStyles}
                />
                <button type="submit" style={buttonStyles}>Envoyer</button>
            </form>
        </div>
    );
}

// Styles pour l'affichage
const popupOverlayStyles = {
    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)', display: 'flex',
    justifyContent: 'center', alignItems: 'center', zIndex: 1000
};

const popupContentStyles = {
    backgroundColor: '#fff', padding: '30px 40px', borderRadius: '8px',
    textAlign: 'center', width: '300px', boxShadow: '0 10px 20px rgba(0, 0, 0, 0.1)'
};

const inputStyles = {
    width: '100%', padding: '10px', marginTop: '20px',
    border: '1px solid #ddd', borderRadius: '4px', fontSize: '16px'
};

const buttonStyles = {
    backgroundColor: '#6c63ff', color: '#fff', padding: '10px 20px',
    border: 'none', borderRadius: '4px', fontSize: '16px', cursor: 'pointer'
};

const buttonContainerStyles = { marginTop: '20px' };

const pseudoStyles = {
    position: 'absolute', top: '10px', left: '10px',
    fontSize: '18px', fontWeight: 'bold', color: '#D3D3D3'
};

export default App;
